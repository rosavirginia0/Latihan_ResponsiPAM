import 'package:flutter/material.dart';
import 'api_service.dart';
import 'web_page.dart';

class DetailPage extends StatelessWidget {
  final String category;
  final int id;
  final ApiService apiService = ApiService();

  DetailPage({required this.category, required this.id});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Detail')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: ApiService.fetchDetail(category, id),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            final data = snapshot.data ?? {};
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(data['title'] ?? 'No Title', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  SizedBox(height: 20),
                  data['image_url'] != null
                      ? Image.network(data['image_url'], width: 200, height: 200, fit: BoxFit.cover)
                      : Icon(Icons.image_not_supported),
                  SizedBox(height: 20),
                  Text(data['summary'] ?? 'No Summary'),
                  Spacer(),
                  // Menempatkan tombol "View More" di pojok kanan bawah
                  Align(
                    alignment: Alignment.bottomRight,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => WebPage(url: data['url']),
                          ),
                        );
                      },
                      child: Text('View More'),
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}