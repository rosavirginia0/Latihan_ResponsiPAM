import 'package:flutter/material.dart';
import 'api_service.dart';
import 'detail_page.dart';

class ListPage extends StatelessWidget {
  final String category;
  final ApiService apiService = ApiService();

  ListPage({required this.category});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(category.toUpperCase())),
      body: FutureBuilder<List<dynamic>>(
        future: apiService.fetchData(category),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            final data = snapshot.data ?? [];
            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),  // Padding untuk spasi antar kotak
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailPage(
                            category: category,
                            id: data[index]['id'],
                          ),
                        ),
                      );
                    },
                    child: Card(
                      elevation: 5,  // Memberikan efek bayangan pada kotak
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),  // Sudut yang melengkung
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),  // Padding di dalam Card
                        child: Row(
                          children: [
                            // Menampilkan gambar thumbnail (bisa disesuaikan)
                            data[index]['image_url'] != null
                                ? Image.network(
                                    data[index]['image_url'],
                                    width: 60,
                                    height: 60,
                                    fit: BoxFit.cover,
                                  )
                                : Icon(Icons.image_not_supported, size: 60),
                            SizedBox(width: 16),  // Spasi antara gambar dan teks
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    data[index]['title'],
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold, fontSize: 16),
                                    overflow: TextOverflow.ellipsis, // Agar teks panjang dipotong
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    data[index]['summary'] ?? 'No summary available.',
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis, // Deskripsi dipotong jika terlalu panjang
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}