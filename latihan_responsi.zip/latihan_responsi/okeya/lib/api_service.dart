import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'https://restaurant-api.dicoding.dev/lis';

  // Ambil data dari API
  Future<List<dynamic>> fetchData(String endpoint) async {
    final url = Uri.parse('$baseUrl/$endpoint/');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      return data['results'];  // Kembalikan daftar data yang termasuk URL gambar
    } else {
      throw Exception('Failed to load data');
    }
  }

  // Ambil detail dari data yang spesifik (termasuk gambar)
  static Future<Map<String, dynamic>> fetchDetail(String category, int id) async {
    final url = Uri.parse('$baseUrl/$category/$id/');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      return json.decode(response.body);  // Mengembalikan detail yang bisa mencakup gambar
    } else {
      throw Exception('Failed to load detail');
    }
  }
}